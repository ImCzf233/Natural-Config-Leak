﻿var scriptName = "Title"
var scriptVersion = 1.1
var scriptAuthor = "San"

var SpaceKingTitle = new SpaceKingTitle()
var client

function SpaceKingTitle() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
    var Message = value.createText("Title", "San Cfg 丨 Buy +q 3182365067 丨 By Yurlu 丨 时间已流逝 :   ");
    var Timer = value.createBoolean("Timer", true);
	var TimerLanguage = value.createList("TimerLanguage", ["China", "England"], "England");
	
	this.getName = function() {
        return "San 4v4 Cfg 7.18"
    }

    this.getDescription = function() {
        return "By RiYanG"
    }

    this.getCategory = function() {
        return "Fun"
    }
    this.onUpdate = function() {
		 HM += 1
		 if (HM ==20){
		   S = S + 1
		   HM = 0
		   
		  }
		 if (S ==60){
		   M = M +1
		   S = 0
		  }
		  if (M==60){
		   H = H+1
		   M = 0
		  }
	if(Timer.get() == true){
							    switch(TimerLanguage.get()) {
						    case "China":
		Display.setTitle(Message.get() + " " +  H  +'  时  '  +M +'  分  '+S+'  秒  ' )
		break;
						    case "England":
									Display.setTitle(Message.get() + " " +  H  +'  Hours  '  +M +'  Minutes  '+S+'  Seconds  ' )
		break;
								}
	} else {
				Display.setTitle(Message.get())
	}
}
	this.addValues = function(values) {
		values.add(Message);
		values.add(Timer);
		values.add(TimerLanguage);
	}
}

var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(SpaceKingTitle)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}